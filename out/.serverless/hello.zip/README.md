# python-serverless-with-dependencies
Python serverless project with dependencies
